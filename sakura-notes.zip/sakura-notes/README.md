# 🌸 Sakura Notes — a washi-paper LaTeX theme

A drop-in LaTeX theme for **study notes that are actually pleasant to read**:
a warm *washi-paper* background, sakura-pink accents, colour-coded callout
boxes, hand-drawn cherry blossoms, part banners, and a matching `pgfplots`
style for figures. Light (paper) and dark (sumi-ink) modes included.

![preview](docs/preview.png)

> This started as one student's course notes, blew up on Reddit, and turned into
> a reusable theme. The full set of notes that started it all is in
> [`showcase/`](showcase/) — use it as a worked example of the theme in action.

---

## ✨ Features

- **One package, one line.** `\usepackage[light]{sakuranotes}` and you're done.
- **Light & dark modes.** `[light]` = washi paper, `[dark]` = sumi-ink night.
- **Six colour-coded boxes** — definitions, theorems, worked examples,
  intuition, properties, notes — plus a centred "key formula" box.
- **Cherry-blossom artwork** drawn in TikZ (no image files), scaled to taste.
- **Title page & part banners** with optional kanji accents.
- **A `pgfplots` style** (`sakuraxis`) so your graphs match the palette.
- **Exposed colour names** you can override in one line.
- **Maths-friendly** helper macros (`\ii`, `\dd`, `\Ft`, `\Lap`, `\sinc`, …).

## 📦 Requirements

- A LaTeX engine with `fontspec`: **XeLaTeX** or **LuaLaTeX** (not pdfLaTeX).
- A reasonably complete TeX Live / MiKTeX (it uses `tcolorbox`, `tikz`,
  `pgfplots`, `titlesec`, `enumitem`, `fancyhdr`, …).
- **Fonts:** Latin Modern (ships with TeX Live). The kanji accents use
  **Noto Serif CJK JP** — if it isn't installed, the theme falls back to the
  main font automatically (you'll just lose the 漢字 flourishes).

## 🚀 Quick start

```bash
# 1. put sakuranotes.sty next to your .tex (or install it — see below)
# 2. build the minimal template:
cd examples
xelatex template.tex      # run twice for cross-references
```

Minimal document:

```latex
\documentclass[11pt]{article}
\usepackage[light]{sakuranotes}      % or [dark]

\renewcommand{\sakuraheadL}{My Course · Notes}
\renewcommand{\sakuraheadR}{Your Name}

\begin{document}
\sakuratitle{My Study Notes}{学習ノート}{a washi-paper template}

\section{Getting started}
Inline maths like $e^{\ii\pi}+1=0$ just works.

\begin{defn}[A term]
Definitions sit in plum boxes.
\end{defn}

\begin{key}
$\displaystyle \int_{-\infty}^{\infty} e^{-x^2}\dd x=\sqrt{\pi}$
\end{key}
\end{document}
```

## 🧰 Installing the theme

**Easiest (per-project):** drop `sakuranotes.sty` in the same folder as your
`.tex`. On **Overleaf**, upload it alongside your file and set the compiler to
*XeLaTeX* (Menu → Compiler).

**System-wide (optional):**

```bash
mkdir -p "$(kpsewhich -var-value TEXMFHOME)/tex/latex/sakuranotes"
cp sakuranotes.sty "$(kpsewhich -var-value TEXMFHOME)/tex/latex/sakuranotes/"
texhash 2>/dev/null || true
```

## 📐 Reference

### Callout boxes

| Environment | Colour | Use for |
|---|---|---|
| `\begin{defn}[title]` | plum | a term being defined |
| `\begin{thm}[title]`  | rose | a central result |
| `\begin{ex}[title]`   | green | a worked example (show all steps) |
| `\begin{intuition}[title]` | gold | the "why" in plain words |
| `\begin{props}[title]` | pink | a list of rules/properties |
| `\begin{note}[title]`  | grey | caveats and asides |
| `\begin{key} … \end{key}` | pink border | a centred formula to memorise |

Roll your own with `\begin{snote}{<colour>}{<title>} … \end{snote}`.

### Structure & cover

```latex
\sakuratitle{<title>}{<kanji or empty>}{<tagline>}   % title page
\notespart{<numeral>}{<title>}{<kanji>}              % part banner
\renewcommand{\sakuraheadL}{<left header>}           % running header (L)
\renewcommand{\sakuraheadR}{<right header>}          % running header (R)
```

### Colours (override after `\usepackage`)

`sakura`, `sakuradeep`, `sakurapale`, `matcha`, `kin`, `ai` (plum),
`ink`, `inkdim`, `pagebg`, `boxbg`, `boxbg2`, `rule`.

```latex
\definecolor{sakura}{HTML}{C85C80}   % e.g. re-tint the whole theme
```

### Figures

Use `pgfplots` with the `sakuraxis` style; primary curve `sakuradeep`,
secondary `matcha` (dashed):

```latex
\begin{tikzpicture}
\begin{axis}[sakuraxis, height=5cm, xlabel={$x$}, ylabel={$f(x)$}]
  \addplot[sakuradeep, samples=120, domain=-3:3]{exp(-x^2)};
\end{axis}
\end{tikzpicture}
```

### Artwork

`\sakuraflower{<scale>}{<colour>}` and `\petal{<scale>}{<colour>}` (use inside a
`tikzpicture`).

## 🏗️ Building everything

```bash
make            # builds the template and the showcase notes
make template   # just the minimal example
make showcase   # just the full ASE203 notes
make clean      # remove LaTeX aux files
```

(or run `xelatex <file>.tex` twice yourself.)

## 📁 Repository layout

```
.
├── sakuranotes.sty            # ← the theme (this is the thing)
├── examples/
│   ├── template.tex           # minimal starter
│   └── template.pdf
├── showcase/
│   ├── ASE203-notes.tex       # the full notes that started it
│   └── ASE203-notes.pdf
├── prompt/
│   └── study-notes-prompt.txt # paste into an AI to make your own
├── docs/
│   └── preview.png
├── Makefile
├── LICENSE                    # MIT
└── README.md
```

## 🤖 Make your own notes with AI

[`prompt/study-notes-prompt.txt`](prompt/study-notes-prompt.txt) is a
copy-paste prompt: give it to a capable assistant along with your slides /
chapter / scribbles and it will generate a full themed PDF using this theme —
faithful content, worked examples, intuition boxes, and matching diagrams.

## ⬆️ Publishing to GitHub

This folder ships as a ready-to-push git repository with an initial commit.

```bash
# set your identity (first time on a machine)
git config user.name  "Your Name"
git config user.email "you@example.com"

# OPTION A — GitHub CLI (easiest):
gh repo create sakura-notes --public --source=. --remote=origin --push

# OPTION B — manually: create an EMPTY repo at https://github.com/new
# (no README/license), then:
git remote add origin https://github.com/<you>/sakura-notes.git
git branch -M main
git push -u origin main
```

Want history fresh under your own name instead?
`rm -rf .git && git init && git add . && git commit -m "Initial commit"`.

## 📜 License

MIT — see [`LICENSE`](LICENSE). Use it, remix it, ship it. Attribution is
appreciated but not required. The showcase notes are an educational summary of
standard course material; the *theme* is the reusable part.

## 🙏 Credits

Theme and notes built collaboratively with **Claude** (Anthropic).
Cherry blossoms are pure TikZ. If you make something nice with it, share it. 🌸
